#
# Insert Seplyr Pipe.R
# 2019-05-13 08:30:11
#

insert_seplyr_pipe <- function() {
    rstudioapi::insertText('%.>%')
}

